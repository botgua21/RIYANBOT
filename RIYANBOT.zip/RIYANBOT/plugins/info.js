let handler  = async (m, { conn, usedPrefix: _p }) => {
  conn.reply(m.chat, `
BOT DI BUAT DI ANDROID MENGGUNAKAN APLIKASI TERMUX
DAN JANGAN LUPA SUBSCRIBE CHANNEL YouTube: Rynz 01
Instragram: @riyanhadi2020
DONASI: 083856085455

`.trim(), m)
}
handler.help = ['info']
handler.tags = ['about']
handler.command = /^(info)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

