let handler  = async (m, { conn, usedPrefix: _p }) => {
  conn.reply(m.chat, `
  
  owner: 0838-5608-5455
  
  chat langsung
  wa.me/6283856085455
  jika butuh bantuan chat aja
  dan jangan lupa subscribe
  YouTube: Rynz 01
  https://youtube.com/channel/UCjOtJKGySNfDUvoA2D2c9_A
  
  `.trim(), m)
}
handler.help = ['owner']
handler.tags = ['about']
handler.command = /^(info)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

